# duchatbot
Chabot with JavaScript ,python flask, torch with python NLTK for console based and web based
